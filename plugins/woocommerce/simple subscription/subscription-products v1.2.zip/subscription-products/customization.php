<?php
include( 'custom-checkout-form.php' );
/**
* Required functions
*/
function is_subscription_in_cart(){
	global $woocommerce;
	$products_in_cart = $woocommerce->cart->get_cart();
	$product_types_in_cart = array_column( $products_in_cart, 'data' );
	if (  $product_types_in_cart[0]->product_type == 'subscription' ) {
		return true;
	}
}

function custom_pre_get_posts_query( $q ) {

	if ( ! $q->is_main_query() ) return;
	if ( ! $q->is_post_type_archive() ) return;
	
	if ( ! is_admin() && is_shop() ) {

		$q->set( 'tax_query', array(array(
			'taxonomy' => 'product_type',
			'field' => 'slug',
			'terms' => array( 'subscription' ), // Don't display subscriptions on the shop page
			'operator' => 'NOT IN'
		)));
	
	}

	remove_action( 'pre_get_posts', 'custom_pre_get_posts_query' );

}
 

function wc_remove_all_quantity_fields( $return, $product ) {

	switch ( $product->product_type ) :
		case "variable":
			return false;
			break;
		case "grouped":
			return false;
			break;
		case "external":
			return false;
		break;
		case "subscription":
			return true;
		default:    // simple product type
			return false;
		break;
	endswitch;
}

function wpluv_redirect_checkout() {
	
	global $woocommerce;
	
	if ( isset( $_POST['add-to-cart'] ) ) {
		
		//Get product ID
		$product_id = (int) apply_filters( 'woocommerce_add_to_cart_product_id', $_POST['add-to-cart'] );

		//Check if current product is subscription
		if ( has_term( 'subscription', 'product_type', $product_id ) ){
			
			$woocommerce->cart->empty_cart();
			$woocommerce->cart->add_to_cart($product_id);
			$checkout_url = $woocommerce->cart->get_checkout_url();
			return $checkout_url;
			
		} else {

			//not working, It may work if ajax will be disabled
			$products_in_cart = $woocommerce->cart->get_cart();
			foreach ( $products_in_cart as $key => $product_in_cart ){
				if ( $product_in_cart['data']->product_type == 'subscription' ){
					$woocommerce->cart->remove_cart_item( $key );
				}
			}
			
		}
	}
	
}

function remove_subscriptions_from_cart() {
	
	global $woocommerce;
	
	$product_id = (int) apply_filters( 'woocommerce_add_to_cart_product_id', $_POST['add-to-cart'] );
	if ( !has_term( 'subscription', 'product_type', $product_id ) ){
		// Run only in the Cart or Checkout Page
		if( is_cart() || is_checkout() ) {
			
			$products_in_cart = $woocommerce->cart->get_cart();
			if ( count( $products_in_cart ) != 1 ){
				foreach ( $products_in_cart as $key => $product_in_cart ){
					if ( $product_in_cart['data']->product_type == 'subscription' ){
						$woocommerce->cart->remove_cart_item( $key );
					}
				}
			}      
		}
	}
}

function reorder_woo_billing_fields( $fields ) {
	$fields2['billing']['billing_first_name'] = $fields['billing']['billing_first_name'];
	$fields2['billing']['billing_last_name'] = $fields['billing']['billing_last_name'];
	$fields2['billing']['billing_email'] = $fields['billing']['billing_email'];
	$fields2['billing']['billing_company'] = $fields['billing']['billing_company'];
	$fields2['billing']['billing_address_1'] = $fields['billing']['billing_address_1'];
	$fields2['billing']['billing_address_2'] = $fields['billing']['billing_address_2'];
	$fields2['billing']['billing_city'] = $fields['billing']['billing_city'];
	$fields2['billing']['billing_country'] = $fields['billing']['billing_country'];
	$fields2['billing']['billing_state'] = $fields['billing']['billing_state'];
	$fields2['billing']['billing_postcode'] = $fields['billing']['billing_postcode'];
	$fields2['billing']['billing_phone'] = $fields['billing']['billing_phone'];
	
	$fields2['billing']['billing_country']['class'] = array('box', 'form-row form-row-first address-field update_totals_on_change validate-required woocommerce-validated');
	$fields2['billing']['billing_state']['class'] = array('box', 'form-row form-row-last address-field validate-required validate-state woocommerce-invalid woocommerce-invalid-required-field');
	$fields2['billing']['billing_postcode']['class'] = array('box', 'form-row form-row-first address-field validate-required validate-postcode');
	$fields2['billing']['billing_phone']['class'] = array('box', 'form-row form-row-last validate-required validate-phone');
	$fields2['billing']['billing_email']['class'] = array('box', 'form-row form-row-wide validate-required validate-email');
	$fields2['billing']['billing_postcode']['clear'] = '';
	$fields2['shipping'] = $fields['shipping'];
    $fields2['account'] = $fields['account'];
    $fields2['order'] = $fields['order'];

	 return $fields2;
}


/**
* Disabling some payment gateways for subscription types
*/

function wpluv_filter_gateways( $gateways ){
    
    global $woocommerce;

    foreach ( $woocommerce->cart->cart_contents as $key => $values ) {
		if( $values['data']->product_type == 'subscription' ){
			unset( $gateways['cheque'] );
			unset( $gateways['cod'] );
			unset( $gateways['bacs'] );
			break;
        }
    }
    return $gateways;
}
//Reordering woocommerce billing form on checkout page
add_filter( 'woocommerce_checkout_fields','reorder_woo_billing_fields' );


add_filter( 'woocommerce_available_payment_gateways', 'wpluv_filter_gateways' );
//place_order button text
add_filter( 'woocommerce_order_button_text', create_function( '', 'return "Pay With PayPal";' ) );

//Excluding a specific product type from shop page
add_action( 'pre_get_posts', 'custom_pre_get_posts_query' );
	
//remove Order Notes from checkout page in Woocommerce
add_filter( 'woocommerce_enable_order_notes_field', '__return_false', 1 );

//remove subscription type if any other product type is added to cart
add_action( 'template_redirect', 'remove_subscriptions_from_cart' );

//Remove all the products in cart, only keep the current one and redirect to checkout page if product type is subscription
add_filter( 'woocommerce_add_to_cart_redirect', 'wpluv_redirect_checkout' );

add_filter( 'woocommerce_is_sold_individually', 'wc_remove_all_quantity_fields', 10, 2 );
