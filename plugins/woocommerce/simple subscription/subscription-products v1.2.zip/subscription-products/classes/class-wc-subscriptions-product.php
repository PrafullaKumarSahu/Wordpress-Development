<?php
class WC_Subscriptions_Product {
	
	public static function init() {
	
		// Because the vanilla price meta field is empty, we need to output our custom subscription description
		add_filter( 'woocommerce_price_html', __CLASS__ . '::get_price_html', 10, 2 );
		add_filter( 'woocommerce_sale_price_html', __CLASS__ . '::get_price_html', 10, 2 );
		add_filter( 'woocommerce_free_price_html', __CLASS__ . '::get_free_price_html', 10, 2 );
		
		// Prevent users from deleting subscription products - it causes too many problems with WooCommerce and other plugins
		add_filter( 'user_has_cap', __CLASS__ . '::user_can_not_delete_subscription', 10, 3 );
		
		// Make sure subscription products in the trash can be restored
		add_filter( 'post_row_actions', __CLASS__ . '::subscription_row_actions', 10, 2 );

		// Remove the "Delete Permanently" bulk action on the Edit Products screen
		add_filter( 'bulk_actions-edit-product', __CLASS__ . '::subscription_bulk_actions', 10 );

		// Do not allow subscription products to be automatically purged on the 'wp_scheduled_delete' hook
		add_action( 'wp_scheduled_delete', __CLASS__ . '::prevent_scheduled_deletion', 9 );
	}
	
	//Output subscription string as the price html
	public static function get_price_html( $price, $product ) {

		if ( WC_Product_Subscription::is_subscription( $product ) )
			$price = self::get_price_string( $product, array( 'price' => $price ) );

		return $price;
	}
	
	/**
	* For products which have a $0 recurring fee, but a sign-up fee, make sure we
	* display the sign-up fee.
	*/
	public static function get_free_price_html( $price, $product ) {

		// Check if it has a sign-up fee (we already know it has no recurring fee)
		if ( WC_Product_Subscription::is_subscription( $product ) && self::get_sign_up_fee( $product ) > 0 )
			$price = self::get_price_string( $product, array( 'price' => $price ) );
		return $price;
	}
	
	//Returns the price per period for a product if it is a subscription.
	public static function get_price( $product ) {

		if ( ! is_object( $product ) )
			$product = WC_Product_Subscription::get_product( $product );

		if ( ! WC_Product_Subscription::is_subscription( $product ) || ( ! isset( $product->subscription_price ) && empty( $product->product_custom_fields['_subscription_price'][0] ) ) ) 
			$subscription_price = '';
		else
			$subscription_price = isset( $product->subscription_price ) ? $product->subscription_price : $product->product_custom_fields['_subscription_price'][0];

		return apply_filters( 'woocommerce_subscriptions_product_price', $subscription_price, $product );
	}
	
	//Returns the sign-up fee for a subscription, if it is a subscription.
	public static function get_sign_up_fee( $product ) {

		if ( ! is_object( $product ) )
			$product = WC_Product_Subscription::get_product( $product );

		if ( ! WC_Product_Subscription::is_subscription( $product ) || ( ! isset( $product->subscription_sign_up_fee ) && empty( $product->product_custom_fields['_subscription_sign_up_fee'][0] ) ) )
			$subscription_sign_up_fee = 0;
		else
			$subscription_sign_up_fee = isset( $product->subscription_sign_up_fee ) ? $product->subscription_sign_up_fee : $product->product_custom_fields['_subscription_sign_up_fee'][0];

		return apply_filters( 'woocommerce_subscriptions_product_sign_up_fee', $subscription_sign_up_fee, $product );
	}
	
	//Calculates a price (could be per period price or sign-up fee) for a subscription less tax if the subscription is taxable and the prices in the store include tax.
	public static function calculate_tax_for_subscription( $price, $product, $deduct_base_taxes = false ) {
		_deprecated_function( __CLASS__ . '::' . __FUNCTION__, '1.5.8', 'WC_Product::get_price_including_tax()' );

		if ( $product->is_taxable() ) {

			$tax = new WC_Tax();

			$base_tax_rates = $tax->get_shop_base_rate( $product->tax_class );
			$tax_rates      = $tax->get_rates( $product->get_tax_class() ); // This will get the base rate unless we're on the checkout page

			if ( $deduct_base_taxes && get_option( 'woocommerce_prices_include_tax' ) == 'yes' ) {

				$base_taxes = $tax->calc_tax( $price, $base_tax_rates, true );
				$taxes      = $tax->calc_tax( $price - array_sum( $base_taxes ), $tax_rates, false );

			} elseif ( get_option( 'woocommerce_prices_include_tax' ) == 'yes' ) {

				$taxes = $tax->calc_tax( $price, $base_tax_rates, true );

			} else {

				$taxes = $tax->calc_tax( $price, $base_tax_rates, false );

			}

			$tax_amount = $tax->get_tax_total( $taxes );

		} else {

			$tax_amount = 0;

		}

		return $tax_amount;
	}	
	
	
	//Returns the subscription interval for a product, if it's a subscription.
	public static function get_interval( $product ) {

		if ( ! is_object( $product ) ) {
			$product = WC_Product_Subscription::get_product( $product );
		}

		if ( ! WC_Product_Subscription::is_subscription( $product ) || ( ! isset( $product->subscription_period_interval ) && empty( $product->product_custom_fields['_subscription_period_interval'][0] ) ) ) {
			$subscription_period_interval = 1;
		} else {
			$subscription_period_interval = isset( $product->subscription_period_interval ) ? $product->subscription_period_interval : $product->product_custom_fields['_subscription_period_interval'][0];
		}

		return apply_filters( 'woocommerce_subscriptions_product_period_interval', $subscription_period_interval, $product );
	}

	//Returns the subscription period for a product, if it's a subscription.
	public static function get_period( $product ) {

		if ( ! is_object( $product ) ) {
			$product = WC_Product_Subscription::get_product( $product );
		}

		if ( ! WC_Product_Subscription::is_subscription( $product ) || ( ! isset( $product->subscription_period ) && empty( $product->product_custom_fields['_subscription_period'][0] ) ) ) {
			$subscription_period = '';
		} else {
			$subscription_period = isset( $product->subscription_period ) ? $product->subscription_period : $product->product_custom_fields['_subscription_period'][0];
		}

		return apply_filters( 'woocommerce_subscriptions_product_period', $subscription_period, $product );
	}
	
	// Returns the length of a subscription product, if it is a subscription.
	public static function get_length( $product ) {

		if ( ! is_object( $product ) ) {
			$product = WC_Product_Subscription::get_product( $product );
		}

		if ( ! WC_Product_Subscription::is_subscription( $product ) || ( ! isset( $product->subscription_length ) && empty( $product->product_custom_fields['_subscription_length'][0] ) ) ) {
			$subscription_length = '';
		} else {
			$subscription_length = isset( $product->subscription_length ) ? $product->subscription_length : $product->product_custom_fields['_subscription_length'][0];
		}

		return apply_filters( 'woocommerce_subscriptions_product_length', $subscription_length, $product );
	}
	
	//Returns the trial length of a subscription product, if it is a subscription.
	public static function get_trial_length( $product ) {

		if ( ! is_object( $product ) ) {
			$product = WC_Product_Subscription::get_product( $product );
		}

		if ( ! WC_Product_Subscription::is_subscription( $product ) || ( ! isset( $product->subscription_trial_length ) && empty( $product->product_custom_fields['_subscription_trial_length'][0] ) ) ) {
			$subscription_trial_length = '';
		} else {
			$subscription_trial_length = isset( $product->subscription_trial_length ) ? $product->subscription_trial_length : $product->product_custom_fields['_subscription_trial_length'][0];
		}

		return apply_filters( 'woocommerce_subscriptions_product_trial_length', $subscription_trial_length, $product );
	}
	
	//Returns the trial period of a subscription product, if it is a subscription.
	public static function get_trial_period( $product ) {

		if ( ! is_object( $product ) ) {
			$product = WC_Product_Subscription::get_product( $product );
		}

		if ( ! WC_Product_Subscription::is_subscription( $product ) ) {
			$subscription_trial_period = '';
		} elseif ( ! isset( $product->subscription_trial_period ) && empty( $product->product_custom_fields['_subscription_trial_period'][0] ) ) { // Backward compatibility
			$subscription_trial_period = self::get_period( $product );
		} else {
			$subscription_trial_period = isset( $product->subscription_trial_period ) ? $product->subscription_trial_period : $product->product_custom_fields['_subscription_trial_period'][0];
		}

		return apply_filters( 'woocommerce_subscriptions_product_trial_period', $subscription_trial_period, $product );
	}



	/**
	* Returns a string representing the details of the subscription. 
	*
	* For example "$20 per Month for 3 Months with a $10 sign-up fee".
	*
	* @param WC_Product|int $product A WC_Product object or ID of a WC_Product.
	* @param array $inclusions An associative array of flags to indicate how to calculate the price and what to include, values:
	*			'tax_calculation'     => false to ignore tax, 'include_tax' or 'exclude_tax' To indicate that tax should be added or excluded respectively
	*			'subscription_length' => true to include subscription's length (default) or false to exclude it
	*			'sign_up_fee'         => true to include subscription's sign up fee (default) or false to exclude it
	*			'price'               => string a price to short-circuit the price calculations and use in a string for the product
	* @since 1.0
	*/
	public static function get_price_string( $product, $include = array() ) {
		global $wp_locale;

		if ( ! is_object( $product ) ) {
			$product = WC_Product_Subscription::get_product( $product );
		}

		if ( ! WC_Product_Subscription::is_subscription( $product ) ) {
			return;
		}

		$include = wp_parse_args( $include, array(
				'tax_calculation'     => get_option( 'woocommerce_tax_display_shop' ),
				'subscription_price'  => true,
				'subscription_period' => true,
				'subscription_length' => true,
				'sign_up_fee'         => true,
				'trial_length'        => true
			)
		);

		$include = apply_filters( 'woocommerce_subscriptions_product_price_string_inclusions', $include, $product );

		$base_price = self::get_price( $product );

		if ( true === $include['sign_up_fee'] ) {
			$sign_up_fee = self::get_sign_up_fee( $product );
		} elseif ( false !== $include['sign_up_fee'] ) { // Allow override of product's sign-up fee
			$sign_up_fee = $include['sign_up_fee'];
		} else {
			$sign_up_fee = 0;
		}

		if ( $include['tax_calculation'] != false ) {

			if ( in_array( $include['tax_calculation'], array( 'exclude_tax', 'excl' ) ) ) { // Subtract Tax

				if ( isset( $include['price'] ) ) {
					$price = $include['price'];
				} else {
					$price = $product->get_price_excluding_tax( 1, $include['price'] );
				}

				if ( true === $include['sign_up_fee'] ) {
					$sign_up_fee = $product->get_sign_up_fee_excluding_tax();
				}

			} else { // Add Tax

				if ( isset( $include['price'] ) ) {
					$price = $include['price'];
				} else {
					$price = $product->get_price_including_tax();
				}

				if ( true === $include['sign_up_fee'] ) {
					$sign_up_fee = $product->get_sign_up_fee_including_tax();
				}

			}

		} else {

			if ( isset( $include['price'] ) ) {
				$price = $include['price'];
			} else {
				$price = woocommerce_price( $base_price );
			}

		}

		$price .= ' <span class="subscription-details">';

		$billing_interval    = self::get_interval( $product );
		$billing_period      = self::get_period( $product );
		$subscription_length = self::get_length( $product );
		$trial_length        = self::get_trial_length( $product );
		$trial_period        = self::get_trial_period( $product );

		if ( is_numeric( $sign_up_fee ) ) {
			$sign_up_fee = woocommerce_price( $sign_up_fee );
		}

		if ( $include['subscription_length'] ) {
			$ranges = WC_Subscriptions_Manager::get_subscription_ranges( $billing_period );
		}

		if ( $include['subscription_length'] && $subscription_length != 0 ) {
			$include_length = true;
		} else {
			$include_length = false;
		}

		$subscription_string = '';

		if ( $include['subscription_price'] && $include['subscription_period'] ) { // Allow extensions to not show price or billing period e.g. Name Your Price
			if ( $include_length && $subscription_length == $billing_interval ) {
				$subscription_string = $price; // Only for one billing period so show "$5 for 3 months" instead of "$5 every 3 months for 3 months"
			} elseif ( WC_Subscriptions_Synchroniser::is_product_synced( $product ) && in_array( $billing_period, array( 'week', 'month', 'year' ) ) ) {
				$payment_day = WC_Subscriptions_Synchroniser::get_products_payment_day( $product );
				switch ( $billing_period ) {
					case 'week':
						$payment_day_of_week = WC_Subscriptions_Synchroniser::get_weekday( $payment_day );
						if ( 1 == $billing_interval ) {
							 // e.g. $5 every Wednesday
							$subscription_string = sprintf( __( '%s every %s', 'woocommerce-subscriptions' ), $price, $payment_day_of_week );
						} else {
							 // e.g. $5 every 2 weeks on Wednesday
							$subscription_string = sprintf( __( '%s every %s on %s', 'woocommerce-subscriptions' ), $price, WC_Subscriptions_Manager::get_subscription_period_strings( $billing_interval, $billing_period ), $payment_day_of_week );
						}
						break;
					case 'month':
						if ( 1 == $billing_interval ) {
							// e.g. $15 on the 15th of each month
							if ( $payment_day > 27 ) {
								$subscription_string = sprintf( __( '%s on the last day of each month', 'woocommerce-subscriptions' ), $price );
							} else {
								$subscription_string = sprintf( __( '%s on the %s of each month', 'woocommerce-subscriptions' ), $price, WC_Product_Subscription::append_numeral_suffix( $payment_day ) );
							}
						} else {
							// e.g. $15 on the 15th of every 3rd month
							if ( $payment_day > 27 ) {
								$subscription_string = sprintf( __( '%s on the last day of every %s month', 'wpluv-subscriptions' ), $price, WC_Product_Subscription::append_numeral_suffix( $billing_interval ) );
							} else {
								$subscription_string = sprintf( __( '%s on the %s day of every %s month', 'wpluv-subscriptions' ), $price, WC_Product_Subscription::append_numeral_suffix( $payment_day ), WC_Product_Subscription::append_numeral_suffix( $billing_interval ) );
							}
						}
						break;
					case 'year':
						if ( 1 == $billing_interval ) {
							// e.g. $15 on March 15th each year
							$subscription_string = sprintf( __( '%s on %s %s each year', 'wpluv-subscriptions' ), $price, $wp_locale->month[ $payment_day['month'] ], WC_Product_Subscription::append_numeral_suffix( $payment_day['day'] ) );
						} else {
							// e.g. $15 on March 15th every 3rd year
							$subscription_string = sprintf( __( '%s on %s %s every %s year', 'wpluv-subscriptions' ), $price, $wp_locale->month[ $payment_day['month'] ], WC_Product_Subscription::append_numeral_suffix( $payment_day['day'] ), WC_Product_Subscription::append_numeral_suffix( $billing_interval ) );
						}
						break;
				}
			} else {
				$subscription_string = sprintf( _n( '%s / %s', ' %s every %s', $billing_interval, 'wpluv-subscriptions' ), $price, WC_Subscriptions_Manager::get_subscription_period_strings( $billing_interval, $billing_period ) );
			}
		} elseif ( $include['subscription_price'] ) {
			$subscription_string = $price;
		} elseif ( $include['subscription_period'] ) {
			$subscription_string = sprintf( _n( '%s', 'every %s', $billing_interval, 'wpluv-subscriptions' ), WC_Subscriptions_Manager::get_subscription_period_strings( $billing_interval, $billing_period ) );
		}

		// Add the length to the end
		if ( $include_length ) {
			$subscription_string = sprintf( __( '%s for %s', 'wpluv-subscriptions' ), $subscription_string, $ranges[ $subscription_length ] );
		}

		if ( $include['trial_length'] && $trial_length != 0 ) {
			$trial_string = WC_Subscriptions_Manager::get_subscription_trial_period_strings( $trial_length, $trial_period );
			$subscription_string = sprintf( __( '%s with %s free trial', 'woocommercezz-subscriptions' ), $subscription_string, $trial_string );
		}

		if ( $include['sign_up_fee'] && self::get_sign_up_fee( $product ) > 0 ) {
			$subscription_string = sprintf( __( '%s and a %s sign-up fee', 'woocommerce-subscriptions' ), $subscription_string, $sign_up_fee );
		}

		$subscription_string .= '</span>';

		return apply_filters( 'woocommerce_subscriptions_product_price_string', $subscription_string, $product, $include );
	}

	/*
	* Takes a subscription product's ID and returns the date on which the subscription product will expire, 
	* based on the subscription's length and calculated from either the $from_date if specified, or the current date/time.
	*/
	public static function get_expiration_date( $product_id, $from_date = '' ) {

		$subscription_length = self::get_length( $product_id );

		if( $subscription_length > 0 ){

			$subscription_period = self::get_period( $product_id );
			$trial_period        = self::get_trial_period( $product_id );
			$trial_length        = self::get_trial_length( $product_id );

			if ( empty( $from_date ) ) {
				$from_date = gmdate( 'Y-m-d H:i:s' );
			}

			$expiration_date = date( 'Y-m-d H:i:s', strtotime( "+ $trial_length {$trial_period}s + $subscription_length {$subscription_period}s", strtotime( $from_date ) ) );

		} else {

			$expiration_date = 0;

		}

		return apply_filters( 'woocommerce_subscriptions_product_expiration_date', $expiration_date, $product_id, $from_date );
	}
	/*
	* Takes a subscription product's ID and returns the date on which the subscription trial will expire,
	 * based on the subscription's trial length and calculated from either the $from_date if specified,
	 * or the current date/time.
	*/
	public static function get_trial_expiration_date( $product_id, $from_date = '' ) {

		$trial_period = self::get_trial_period( $product_id );
		$trial_length = self::get_trial_length( $product_id );

		if( $trial_length > 0 ){

			if ( empty( $from_date ) ) {
				$from_date = gmdate( 'Y-m-d H:i:s' );
			}

			if ( 'month' == $trial_period ) {
				$trial_expiration_date = date( 'Y-m-d H:i:s', WC_Product_Subscription::add_months( strtotime( $from_date ), $trial_length ) );
			} else { // Safe to just add the billing periods
				$trial_expiration_date = date( 'Y-m-d H:i:s', strtotime( "+ {$trial_length} {$trial_period}s", strtotime( $from_date ) ) );
			}

		} else {

			$trial_expiration_date = 0;

		}

		return apply_filters( 'woocommerce_subscriptions_product_trial_expiration_date', $trial_expiration_date, $product_id, $from_date );
	}

	
	/**
	* Do not allow any user to delete a subscription product if it is associated with an order.
	*
	* Those with appropriate capabilities can still trash the product, but they will not be able to permanently
	* delete the product if it is associated with an order (i.e. been purchased).
	*
	*
	*/
	public static function user_can_not_delete_subscription( $allcaps, $caps, $args ) {
		global $wpdb;

		if ( isset( $args[0] ) && in_array( $args[0], array( 'delete_post', 'delete_product' ) ) && isset( $args[2] ) && ( ! isset( $_GET['action'] ) || 'untrash' != $_GET['action'] ) ) {

			$user_id = $args[2];
			$post_id = $args[2];
			$product = get_product( $post_id );

			if ( false !== $product && 'trash' == $product->post->post_status && $product->is_type( array( 'subscription' ) ) ) {

				$product_id = ( $product->is_type( 'subscription' ) ) ? $product->post->ID : $post_id;

				$subscription_count = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$wpdb->prefix}woocommerce_order_itemmeta` WHERE `meta_key` = '_product_id' AND `meta_value` = %d", $product_id ) );

				if ( $subscription_count > 0 ) {
					$allcaps[ $caps[0] ] = false;
				}
			}

		}

		return $allcaps;
	}
	
	/**
	* Remove the "Delete Permanently" action from the bulk actions select element on the Products admin screen.
	*
	* Because any subscription products associated with an order can not be permanently deleted (as a result of
	* @see self::user_can_not_delete_subscription() ), leaving the bulk action in can lead to the store manager
	* hitting the "You are not allowed to delete this item" brick wall and not being able to continue with the
	* deletion (or get any more detailed information about which item can't be deleted and why).
	*
	* @return array $actions Array of actions that can be performed on the post.
	* 
	*/
	public static function subscription_bulk_actions( $actions ) {

		unset( $actions['delete'] );

		return $actions;
	}
	
	/**
	* Make sure the 'untrash' (i.e. "Restore") row action is displayed.
	*
	* In @see self::user_can_not_delete_subscription() we prevent a store manager being able to delete a subscription product.
	* However, WooCommerce also uses the `delete_post` capability to check whether to display the 'trash' and 'untrash' row actions.
	* We want a store manager to be able to trash and untrash subscriptions, so this function adds them again.
	*
	* @return array $actions Array of actions that can be performed on the post.
	* @return array $post Array of post values for the current product (or post object if it is not a product).
	* 
	*/
	public static function subscription_row_actions( $actions, $post ) {
		global $the_product;

		if ( ! empty( $the_product ) && ! isset( $actions['untrash'] ) && $the_product->is_type( array( 'subscription' ) ) ) {

			$post_type_object = get_post_type_object( $post->post_type );

			if ( 'trash' == $post->post_status && current_user_can( $post_type_object->cap->edit_post, $post->ID ) ) {
				$actions['untrash'] = "<a title='" . esc_attr( __( 'Restore this item from the Trash' ) ) . "' href='" . wp_nonce_url( admin_url( sprintf( $post_type_object->_edit_link . '&amp;action=untrash', $post->ID ) ), 'untrash-post_' . $post->ID ) . "'>" . __( 'Restore' ) . "</a>";
			}

		}

		return $actions;
	}
	
	/**
	* Hooked to the @see 'wp_scheduled_delete' WP-Cron scheduled task to rename the '_wp_trash_meta_time' meta value
	* as '_wc_trash_meta_time'. This is the flag used by WordPress to determine which posts should be automatically
	* purged from the trash. We want to make sure Subscriptions products are not automatically purged (but still want
	* to keep a record of when the product was trashed).
	*
	* 
	*/
	public static function prevent_scheduled_deletion() {
		global $wpdb;

		$query =   "UPDATE $wpdb->postmeta
					INNER JOIN $wpdb->posts ON $wpdb->postmeta.post_id = $wpdb->posts.ID
					SET $wpdb->postmeta.meta_key = '_wc_trash_meta_time'
					WHERE $wpdb->postmeta.meta_key = '_wp_trash_meta_time'
					AND $wpdb->posts.post_type IN ( 'product', 'product_variation')
					AND $wpdb->posts.post_status = 'trash'";

		$wpdb->query( $query );
	}
	
	
	//Returns the sign-up fee for a subscription excluding tax - ignores tax_class filters since the price may *include* tax and thus needs subtracting
	public static function get_sign_up_fee_excluding_tax( $product ) {

		$price = self::get_sign_up_fee( $product );

		if ( $product->is_taxable() && get_option( 'woocommerce_prices_include_tax' ) == 'yes' ) :

			$_tax = new WC_Tax();

			$tax_rates  = $_tax->get_shop_base_rate( $product->tax_class );
			$taxes      = $_tax->calc_tax( $price, $tax_rates, true );
			$tax_amount = $_tax->get_tax_total( $taxes );
			$price      = round( $price - $tax_amount, 2);

		endif;

		return $price;
	}
}
WC_Subscriptions_Product::init();
