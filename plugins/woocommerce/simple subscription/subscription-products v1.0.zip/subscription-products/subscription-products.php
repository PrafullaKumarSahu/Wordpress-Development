<?php
/**
 * Plugin Name: Subscription Products
 * Plugin URI: http://woothemes.com/products/subscription-products/
 * Description: Sell products and services with recurring payments in your WooCommerce Store.
 * Version: 1.0.0
 * Author: Indibits
 * Author URI: http://indibits.com/
 * Developer: Indibits
 * Developer URI: http://indibits.com/
 * Text Domain: wpluv-subscriptions
 * Domain Path: /languages
 *
 * Copyright: © 2009-2015 Indibits.
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	
	//Add subscription type product to woocommerce
	add_action('plugins_loaded', 'wpluv_subscriptions');
}

function wpluv_subscriptions(){

	//Custom Checkout Form
	require_once( 'customization.php' );
	
	require_once( 'classes/class-wc-subscriptions-product.php' );

	require_once( 'classes/class-wc-subscriptions-admin.php' );

	require_once( 'classes/class-wc-subscriptions-manager.php' );

	require_once( 'classes/class-wc-subscriptions-order.php' );

	require_once( 'classes/class-wc-subscriptions-cart.php' );

	require_once( 'classes/class-wc-subscriptions-renewal-order.php' );

	require_once( 'classes/class-wc-subscriptions-checkout.php' );

	require_once( 'classes/class-wc-subscriptions-change-payment-gateway.php' );

	require_once( 'classes/gateways/class-wc-subscriptions-payment-gateways.php' );

	require_once( 'classes/gateways/gateway-paypal-standard-subscriptions.php' );

	require_once( 'classes/class-wc-subscriptions-synchroniser.php' );

	/**
	 * @class 		WC_Product_Subscription
	 */
	class WC_Product_Subscription extends WC_Product {
	
		public static $name = 'subscription';
		
		var $subscription_price;

		var $subscription_period;

		var $subscription_period_interval;

		var $subscription_length;

		public function __construct( $product ) {
			
			parent::__construct( $product );
			
			$this->product_type = 'subscription';

			// Load all meta fields
			$this->product_custom_fields = get_post_meta( $this->id );

			// Convert selected subscription meta fields for easy access
			if ( ! empty( $this->product_custom_fields['_subscription_price'][0] ) )
				$this->subscription_price = $this->product_custom_fields['_subscription_price'][0];

			if ( ! empty( $this->product_custom_fields['_subscription_period'][0] ) )
				$this->subscription_period = $this->product_custom_fields['_subscription_period'][0];

			if ( ! empty( $this->product_custom_fields['_subscription_period_interval'][0] ) )
				$this->subscription_period_interval = $this->product_custom_fields['_subscription_period_interval'][0];

			if ( ! empty( $this->product_custom_fields['_subscription_length'][0] ) )
				$this->subscription_length = $this->product_custom_fields['_subscription_length'][0];
				
			$this->subscription_payment_sync_date = ( ! isset( $this->product_custom_fields['_subscription_payment_sync_date'][0] ) ) ? 0 : maybe_unserialize( $this->product_custom_fields['_subscription_payment_sync_date'][0] );

			$this->limit_subscriptions = ( ! isset( $this->product_custom_fields['_subscription_limit'][0] ) ) ? 'no' : $this->product_custom_fields['_subscription_limit'][0];
			
			add_action( 'woocommerce_subscription_add_to_cart', __CLASS__ . '::subscription_add_to_cart', 30 );

			// Update Order totals via Ajax when a order form is updated
			add_action( 'wp_ajax_woocommerce_subscriptions_update_order_total', __CLASS__ . '::ajax_get_order_totals' );
			add_action( 'wp_ajax_nopriv_woocommerce_subscriptions_update_order_total', __CLASS__ . '::ajax_get_order_totals' );

		}
		
		public static function subscription_add_to_cart(){
			woocommerce_get_template( 'subscription.php', array( ), '', plugin_dir_path( __FILE__ ) . '/templates/single-product/add-to-cart/' );
		}

		/*
		 * Get the add to cart button text for the single page
		 *
		 * @access public
		 * @return string
		 */
		public function single_add_to_cart_text() {
			return apply_filters( 'woocommerce_product_single_add_to_cart_text', self::add_to_cart_text(), $this );
		}
		
		public function add_to_cart_text() {

			if ( $this->is_purchasable() && $this->is_in_stock() ) {
				$text = get_option( WC_Subscriptions_Admin::$option_prefix . '_add_to_cart_button_text', __( 'Purchase', 'wpluv-subscriptions' ) );
			} else {
				$text = parent::add_to_cart_text(); // translated "Read More"
			}

			return apply_filters( 'woocommerce_product_add_to_cart_text', $text, $this );
		}
		/*
		 * Get's a WC_Product using the new core WC @see get_product() function if available, otherwise
		 * instantiating an instance of the WC_Product class.
		 *
		 * @since 1.2.4
		 */
		public static function get_product( $product_id ) {

			if ( function_exists( 'get_product' ) )
				$product = get_product( $product_id );
			else
				$product = new WC_Product( $product_id );  // Shouldn't matter if product is variation as all we need is the product_type

			return $product;
		}
		
		/**
		 * Workaround the last day of month quirk in PHP's strtotime function.
		 *
		 * Adding +1 month to the last day of the month can yield unexpected results with strtotime().
		 * For example, 
		 * - 30 Jan 2013 + 1 month = 3rd March 2013
		 * - 28 Feb 2013 + 1 month = 28th March 2013
		 *
		 * What humans usually want is for the charge to continue on the last day of the month.
		 *
		 * @since 1.2.5
		 */
		public static function add_months( $from_timestamp, $months_to_add ) {

			$first_day_of_month = date( 'Y-m', $from_timestamp ) . '-1';
			$days_in_next_month = date( 't', strtotime( "+ {$months_to_add} month", strtotime( $first_day_of_month ) ) );

			// Payment is on the last day of the month OR number of days in next billing month is less than the the day of this month (i.e. current billing date is 30th January, next billing date can't be 30th February)
			if ( date( 'd m Y', $from_timestamp ) === date( 't m Y', $from_timestamp ) || date( 'd', $from_timestamp ) > $days_in_next_month ) {
				for ( $i = 1; $i <= $months_to_add; $i++ ) {
					$next_month = strtotime( '+ 3 days', $from_timestamp ); // Add 3 days to make sure we get to the next month, even when it's the 29th day of a month with 31 days
					$next_timestamp = $from_timestamp = strtotime( date( 'Y-m-t H:i:s', $next_month ) ); // NB the "t" to get last day of next month
				}
			} else { // Safe to just add a month
				$next_timestamp = strtotime( "+ {$months_to_add} month", $from_timestamp );
			}

			return $next_timestamp;
		}
		
		public static function is_woocommerce_pre_2_1() {

			if ( ! defined( 'WC_VERSION' ) ) {
				$woocommerce_is_pre_2_1 = true;
			} else {
				$woocommerce_is_pre_2_1 = false;
			}

			return $woocommerce_is_pre_2_1;
		}
		
		public static function is_subscription( $product_id ) {

			$is_subscription = false;

			if ( is_object( $product_id ) )
				$product_id = $product_id->id;

			$post_type = get_post_type( $product_id );

			if ( in_array( $post_type, array( 'product', 'product_variation' ) ) ) {

				$product = get_product( $product_id );

				if ( $product->is_type( array( 'subscription', 'subscription_variation', 'variable-subscription' ) ) )
					$is_subscription = true;

			}

			return apply_filters( 'woocommerce_is_subscription', $is_subscription, $product_id );
		}
		public static function format_total( $number ) {
			global $woocommerce;

			if ( function_exists( 'wc_format_decimal' ) ) {
				return wc_format_decimal( $number );
			} else { // WC < 2.1
				return woocommerce_format_total( $number );
			}
		}
		public static function append_numeral_suffix( $number ) {

			// If the tens digit of a number is 1, then write "th" after the number. For example: 13th, 19th, 112th, 9311th. http://en.wikipedia.org/wiki/English_numerals
			if ( strlen( $number ) > 1 && substr( $number, -2 ) ) {
				$number_string = sprintf( __( '%sth', 'wpluv-subscriptions' ), $number );
			} else { // Append relevant suffix
				switch( substr( $number, -1 ) ) {
					case 1:
						$number_string = sprintf( __( '%sst', 'wpluv-subscriptions' ), $number );
						break;
					case 2:
						$number_string = sprintf( __( '%snd', 'wpluv-subscriptions' ), $number );
						break;
					case 3:
						$number_string = sprintf( __( '%srd', 'wpluv-subscriptions' ), $number );
						break;
					default:
						$number_string = sprintf( __( '%sth', 'wpluv-subscriptions' ), $number );
						break;
				}
			}

			return apply_filters( 'woocommerce_numeral_suffix', $number_string, $number );
		}
		public static function add_notice( $message, $notice_type = 'success' ) {
			global $woocommerce;

			if ( function_exists( 'wc_add_notice' ) ) {

				wc_add_notice( $message, $notice_type );

			} else { // WC < 2.1

				if ( 'error' === $notice_type ) {
					$woocommerce->add_error( $message );
				} else {
					$woocommerce->add_message( $message );
				}

				$woocommerce->set_messages();

			}
		}
		public static function print_notices() {
			global $woocommerce;

			if ( function_exists( 'wc_print_notices' ) ) {

				wc_print_notices();

			} else { // WC < 2.1

				$woocommerce->show_messages();

			}
		}
		public static function is_woocommerce_pre_2_2() {

			if ( ! defined( 'WC_VERSION' ) || version_compare( WC_VERSION, '2.2', '<' ) ) {
				$woocommerce_is_pre_2_2 = true;
			} else {
				$woocommerce_is_pre_2_2 = false;
			}

			return $woocommerce_is_pre_2_2;
		}
	}
}