<?php
class WC_Subscriptions_Renewal_Order {

	public static $product_deleted_error_message;

	/**
	 * Bootstraps the class and hooks required actions & filters.
	 *
	 * @since 1.0
	 */
	public static function init() {
	
		// Generate an order to keep a record of each subscription payment
		add_action( 'processed_subscription_payment', __CLASS__ . '::generates_paid_renewal_order', 10, 2 );
		add_action( 'processed_subscription_payment_failure', __CLASS__ . '::generate_failed_payment_renewal_order', 10, 2 );
		
		// If a subscription requires manual payment, generate an order to accept the payment
		add_action( 'scheduled_subscription_payment', __CLASS__ . '::maybe_generate_manual_renewal_order', 10, 2 );

	}
	public static function is_renewal( $order, $args = array() ) {

		if ( ! is_object( $order ) ) {
			$order = new WC_Order( $order );
		}

		if ( ! is_array( $args ) ) {
			_deprecated_argument( __CLASS__ . '::' . __FUNCTION__, '1.3', __( 'Second parameter is now an array of name => value pairs. Use array( "order_role" => "child" ) instead.', 'wpluv-subscriptions' ) );
			$args = array(
				'order_role' => $args,
			);
		}

		$args = wp_parse_args( $args, array(
			'order_role'   => '',
			'via_checkout' => false,
			)
		);

		if ( WC_Subscriptions_Order::get_meta( $order, 'original_order', false ) ) {
			$is_renewal = true;
		} else {
			$is_renewal = false;
		}

		if ( ! empty ( $args['order_role'] ) ) {
			$order_post = get_post( $order->id );

			if ( 'parent' == $args['order_role'] && 0 != $order_post->post_parent ) { // It's a child order
				$is_renewal = false;
			} elseif ( 'child' == $args['order_role'] && 0 == $order_post->post_parent ) { // It's a parent order
				$is_renewal = false;
			}
		}

		// Further qualify whether renewal order was via the cart/checkout process
		if ( true === $args['via_checkout'] && 'yes' != get_post_meta( $order->id, '_checkout_renewal', true ) ) {
			$is_renewal = false;
		}

		return apply_filters( 'woocommerce_subscriptions_is_renewal_order', $is_renewal, $order );
	}
	public static function get_parent_order_id( $renewal_order ) {

		$parent_order = self::get_parent_order( $renewal_order );

		return $parent_order->id;
	}
	public static function get_parent_order( $renewal_order ) {

		if ( ! is_object( $renewal_order ) ) {
			$renewal_order = new WC_Order( $renewal_order );
		}

		$order_post = get_post( $renewal_order->id );

		if ( 0 == $order_post->post_parent ) {  // The renewal order is the parent order
			$parent_order = $renewal_order;
		} else {
			$parent_order = new WC_Order( $order_post->post_parent );
		}

		return apply_filters( 'woocommerce_subscriptions_parent_order', $parent_order, $renewal_order );
	}
	public static function generate_paid_renewal_order( $user_id, $subscription_key ) {
		global $woocommerce;

		$subscription = WC_Subscriptions_Manager::get_subscription( $subscription_key );

		$parent_order = new WC_Order( $subscription['order_id'] );

		$renewal_order_id = self::generate_renewal_order( $parent_order, $subscription['product_id'], array( 'new_order_role' => 'child' ) );

		$renewal_order = new WC_Order( $renewal_order_id );

		// Don't duplicate renewal orders
		remove_action( 'processed_subscription_payment', __CLASS__ . '::generate_paid_renewal_order', 10, 2 );

		$renewal_order->payment_complete();

		// But make sure orders are still generated for other payments in the same request
		add_action( 'processed_subscription_payment', __CLASS__ . '::generate_paid_renewal_order', 10, 2 );

		WC_Subscriptions_Manager::reactivate_subscription( $user_id, $subscription_key );

		$parent_order->add_order_note( sprintf( __( 'Subscription payment recorded in renewal order %s', 'woocommerce-subscriptions' ), $renewal_order->get_order_number() ) );

		return $renewal_order_id;
	}
	
	public static function generate_failed_payment_renewal_order( $user_id, $subscription_key ) {

		$subscription = WC_Subscriptions_Manager::get_subscription( $subscription_key );

		$renewal_order_id = self::generate_renewal_order( $subscription['order_id'], $subscription['product_id'], array( 'new_order_role' => 'child' ) );

		// Mark payment completed on order
		$renewal_order = new WC_Order( $renewal_order_id );

		$renewal_order->update_status( 'failed' );

		return $renewal_order_id;
	}
	


	public static function generate_renewal_order( $original_order, $product_id, $args = array() ) {
	
		global $wpdb, $woocommerce;

		if ( ! is_object( $original_order ) ) {
			$original_order = new WC_Order( $original_order );
		}

		if ( ! WC_Subscriptions_Order::order_contains_subscription( $original_order ) || ! WC_Subscriptions_Order::is_item_subscription( $original_order, $product_id ) ) {
			return false;
		}

		if ( self::is_renewal( $original_order, array( 'order_role' => 'child' ) ) ) {
			$original_order = self::get_parent_order( $original_order );
		}

		if ( ! is_array( $args ) ) {
			_deprecated_argument( __CLASS__ . '::' . __FUNCTION__, '1.3', __( 'Third parameter is now an array of name => value pairs. Use array( "new_order_role" => "parent" ) instead.', 'woocommerce-subscriptions' ) );
			$args = array(
				'new_order_role' => $args,
			);
		}

		$args = wp_parse_args( $args, array(
			'new_order_role'   => 'parent',
			'checkout_renewal' => false,
			)
		);

		$renewal_order_key = uniqid( 'order_' );

		// Create the new order
		$renewal_order_data = array(
			'post_type'     => 'shop_order',
			'post_title' 	=> sprintf( __( 'Subscription Renewal Order &ndash; %s', 'woocommerce-subscriptions' ), strftime( _x( '%b %d, %Y @ %I:%M %p', 'Order date parsed by strftime', 'woocommerce-subscriptions' ) ) ),
			'post_status'   => 'publish',
			'ping_status'   => 'closed',
			'post_excerpt'  => $original_order->customer_note,
			'post_author'   => 1,
			'post_password' => $renewal_order_key,
		);

		$create_new_order = true;

		if ( 'child' == $args['new_order_role'] ) {
			$renewal_order_data['post_parent'] = $original_order->id;
		}

		if ( true === $args['checkout_renewal'] ) {

			$renewal_order_id = null;

			if ( $woocommerce->session->order_awaiting_payment > 0 ) {
				$renewal_order_id = absint( $woocommerce->session->order_awaiting_payment );
			} elseif ( isset( $args['failed_order_id'] ) ) {

				$failed_order_id = $args['failed_order_id'];

				/* Check order is unpaid by getting its status */
				$terms = wp_get_object_terms( $failed_order_id, 'shop_order_status', array( 'fields' => 'slugs' ) );
				$order_status = isset( $terms[0] ) ? $terms[0] : 'pending';

				/* If paying on a pending order, we are resuming */
				if ( $order_status == 'pending' ) {
					$renewal_order_id = $failed_order_id;
				}
			}

			if ( $renewal_order_id ) {

				/* Check order is unpaid by getting its status */
				$terms = wp_get_object_terms( $renewal_order_id, 'shop_order_status', array( 'fields' => 'slugs' ) );
				$order_status = isset( $terms[0] ) ? $terms[0] : 'pending';

				// Resume the unpaid order if its pending
				if ( $order_status == 'pending' || $order_status == 'failed' ) {

					// Update the existing order as we are resuming it
					$create_new_order = false;
					$renewal_order_data['ID'] = $renewal_order_id;
					wp_update_post( $renewal_order_data );

					// Clear the old line items - we'll add these again in case they changed
					$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}woocommerce_order_itemmeta WHERE order_item_id IN ( SELECT order_item_id FROM {$wpdb->prefix}woocommerce_order_items WHERE order_id = %d )", $renewal_order_id ) );

					$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}woocommerce_order_items WHERE order_id = %d", $renewal_order_id ) );
				}
			}
		}

		if ( $create_new_order ) {
			$renewal_order_id = wp_insert_post( $renewal_order_data );
		}

		// Set the order as pending
		wp_set_object_terms( $renewal_order_id, 'pending', 'shop_order_status' );

		// Set a unique key for this order
		update_post_meta( $renewal_order_id, '_order_key', $renewal_order_key );

		$order_meta_query = "SELECT `meta_key`, `meta_value`
							 FROM $wpdb->postmeta
							 WHERE `post_id` = $original_order->id
							 AND `meta_key` NOT IN ('_paid_date', '_completed_date', '_order_key', '_edit_lock', '_original_order', '_wc_points_earned')";

		// Superseding existing order so don't carry over payment details
		if ( 'parent' == $args['new_order_role'] || true === $args['checkout_renewal'] ) {
			$order_meta_query .= " AND `meta_key` NOT IN ('_payment_method', '_payment_method_title', '_recurring_payment_method', '_recurring_payment_method_title', '_shipping_method', '_shipping_method_title', '_recurring_shipping_method', '_recurring_shipping_method_title')";
		} else {
			$order_meta_query .= " AND `meta_key` NOT LIKE '_order_recurring_%' AND `meta_key` NOT IN ('_payment_method', '_payment_method_title', '_recurring_payment_method', '_recurring_payment_method_title', '_shipping_method', '_shipping_method_title', '_recurring_shipping_method', '_recurring_shipping_method_title')";
		}

		// Allow extensions to add/remove order meta
		$order_meta_query = apply_filters( 'woocommerce_subscriptions_renewal_order_meta_query', $order_meta_query, $original_order->id, $renewal_order_id, $args['new_order_role'] );

		// Carry all the required meta from the old order over to the new order
		$order_meta = $wpdb->get_results( $order_meta_query, 'ARRAY_A' );

		$order_meta = apply_filters( 'woocommerce_subscriptions_renewal_order_meta', $order_meta, $original_order->id, $renewal_order_id, $args['new_order_role'] );

		foreach( $order_meta as $meta_item ) {
			add_post_meta( $renewal_order_id, $meta_item['meta_key'], maybe_unserialize( $meta_item['meta_value'] ), true );
		}

		//$outstanding_balance       = WC_Subscriptions_Order::get_outstanding_balance( $original_order, $product_id );
		$failed_payment_multiplier = 1;

		if ( false == $args['checkout_renewal'] ) {

			// If there are outstanding payment amounts, add them to the order, otherwise set the order details to the values of the recurring totals
			if ( 'yes' == get_option( WC_Subscriptions_Admin::$option_prefix . '_add_outstanding_balance', 'no' ) ) {
				$failed_payment_multiplier = WC_Subscriptions_Order::get_failed_payment_count( $original_order, $product_id );
			}

			// Set order totals based on recurring totals from the original order
			$cart_discount      = $failed_payment_multiplier * get_post_meta( $original_order->id, '_order_recurring_discount_cart', true );
			$order_discount     = $failed_payment_multiplier * get_post_meta( $original_order->id, '_order_recurring_discount_total', true );
			$order_shipping_tax = $failed_payment_multiplier * get_post_meta( $original_order->id, '_order_recurring_shipping_tax_total', true );
			$order_shipping     = $failed_payment_multiplier * get_post_meta( $original_order->id, '_order_recurring_shipping_total', true );
			$order_tax          = $failed_payment_multiplier * get_post_meta( $original_order->id, '_order_recurring_tax_total', true );
			$order_total        = $failed_payment_multiplier * get_post_meta( $original_order->id, '_order_recurring_total', true );

			update_post_meta( $renewal_order_id, '_cart_discount', $cart_discount );
			update_post_meta( $renewal_order_id, '_order_discount', $order_discount );
			update_post_meta( $renewal_order_id, '_order_shipping_tax', $order_shipping_tax );
			update_post_meta( $renewal_order_id, '_order_shipping', $order_shipping );
			update_post_meta( $renewal_order_id, '_order_tax', $order_tax );
			update_post_meta( $renewal_order_id, '_order_total', $order_total );

			// Set shipping for orders created with WC 2.0.n (or when we are using WC 2.0.n)
			if ( WC_Product_Subscription::is_woocommerce_pre_2_1() || isset( $original_order->recurring_shipping_method ) ) {

				update_post_meta( $renewal_order_id, '_shipping_method', $original_order->recurring_shipping_method );
				update_post_meta( $renewal_order_id, '_shipping_method_title', $original_order->recurring_shipping_method_title );

				// Also set recurring shipping as it's a parent renewal order
				if ( 'parent' == $args['new_order_role'] ) {
					update_post_meta( $renewal_order_id, '_recurring_shipping_method', $original_order->recurring_shipping_method );
					update_post_meta( $renewal_order_id, '_recurring_shipping_method_title', $original_order->recurring_shipping_method_title );
				}

			}

			// Apply the recurring shipping & payment methods to child renewal orders
			if ( 'child' == $args['new_order_role'] ) {
				update_post_meta( $renewal_order_id, '_payment_method', $original_order->recurring_payment_method );
				update_post_meta( $renewal_order_id, '_payment_method_title', $original_order->recurring_payment_method_title );
			}

			// Set order taxes based on recurring taxes from the original order
			$recurring_order_taxes = WC_Subscriptions_Order::get_recurring_taxes( $original_order );

			foreach ( $recurring_order_taxes as $index => $recurring_order_tax ) {

				$item_ids = array();

				$item_ids[] = woocommerce_add_order_item( $renewal_order_id, array(
					'order_item_name' => $recurring_order_tax['name'],
					'order_item_type' => 'tax'
				) );

				// Also set recurring taxes on parent renewal orders
				if ( 'parent' == $args['new_order_role'] ) {
					$item_ids[] = woocommerce_add_order_item( $renewal_order_id, array(
						'order_item_name' => $recurring_order_tax['name'],
						'order_item_type' => 'recurring_tax'
					) );
				}

				// Add line item meta
				foreach( $item_ids as $item_id ) {

					woocommerce_add_order_item_meta( $item_id, 'compound', absint( isset( $recurring_order_tax['compound'] ) ? $recurring_order_tax['compound'] : 0 ) );
					woocommerce_add_order_item_meta( $item_id, 'tax_amount', woocommerce_clean( $failed_payment_multiplier * $recurring_order_tax['tax_amount'] ) );
					woocommerce_add_order_item_meta( $item_id, 'shipping_tax_amount', woocommerce_clean( $failed_payment_multiplier * $recurring_order_tax['shipping_tax_amount'] ) );

					if ( isset( $recurring_order_tax['rate_id'] ) ) {
						woocommerce_add_order_item_meta( $item_id, 'rate_id', $recurring_order_tax['rate_id'] );
					}

					if ( isset( $recurring_order_tax['label'] ) ) {
						woocommerce_add_order_item_meta( $item_id, 'label', $recurring_order_tax['label'] );
					}
				}
			}

			// Set up shipping items on renewal order
			$recurring_shipping_items = WC_Subscriptions_Order::get_recurring_shipping_methods( $original_order );

			foreach ( $recurring_shipping_items as $index => $recurring_shipping_item ) {

				$item_ids = array();

				$item_ids[] = woocommerce_add_order_item( $renewal_order_id, array(
					'order_item_name' => $recurring_shipping_item['name'],
					'order_item_type' => 'shipping'
				) );

				// Also set recurring shipping as it's a parent renewal order
				if ( 'parent' == $args['new_order_role'] ) {
					$item_ids[] = woocommerce_add_order_item( $renewal_order_id, array(
						'order_item_name' => $recurring_shipping_item['name'],
						'order_item_type' => 'recurring_shipping'
					) );
				}

				// Add shipping item meta
				foreach( $item_ids as $item_id ) {
					woocommerce_add_order_item_meta( $item_id, 'method_id', $recurring_shipping_item['method_id'] );
					woocommerce_add_order_item_meta( $item_id, 'cost', woocommerce_clean( $failed_payment_multiplier * $recurring_shipping_item['cost'] ) );
				}
			}

		}

		// Set line totals to be recurring line totals and remove the subscription/recurring related item meta from each order item
		$order_items = WC_Subscriptions_Order::get_recurring_items( $original_order );

		// Allow extensions to add/remove items or item meta
		$order_items = apply_filters( 'woocommerce_subscriptions_renewal_order_items', $order_items, $original_order->id, $renewal_order_id, $product_id, $args['new_order_role'] );

		if ( true === $args['checkout_renewal'] ) {
			$cart_items = $woocommerce->cart->get_cart();
		}

		foreach ( $order_items as $item_index => $order_item ) {

			if ( 'child' == $args['new_order_role'] ) {
				$renewal_order_item_name = sprintf( __( 'Renewal of "%s" purchased in Order %s', 'woocommerce-subscriptions' ), $order_item['name'], $original_order->get_order_number() );
			} else {
				$renewal_order_item_name = $order_item['name'];
			}

			$renewal_order_item_name = apply_filters( 'woocommerce_subscriptions_renewal_order_item_name', $renewal_order_item_name, $order_item, $original_order );

			// Create order line item on the renewal order
			$recurring_item_id = woocommerce_add_order_item( $renewal_order_id, array(
				'order_item_name' => $renewal_order_item_name,
				'order_item_type' => 'line_item'
			));

			if ( true === $args['checkout_renewal'] ) {

				$cart_item = array();

				foreach ( $cart_items as $item ) {
					if ( $item['product_id'] == $order_item['product_id'] && ( empty( $order_item['variation_id'] ) || $item['variation_id'] == $order_item['variation_id']) ) {
						$cart_item = $item;
					}
				}

				if ( ! empty( $cart_item ) ) {
					woocommerce_update_order_item_meta( $recurring_item_id, '_line_total', woocommerce_format_decimal( $cart_item['line_total'] ) );
					woocommerce_update_order_item_meta( $recurring_item_id, '_line_tax', woocommerce_format_decimal( $cart_item['line_tax'] ) );
					woocommerce_update_order_item_meta( $recurring_item_id, '_line_subtotal', woocommerce_format_decimal( $cart_item['line_subtotal'] ) );
					woocommerce_update_order_item_meta( $recurring_item_id, '_line_subtotal_tax', woocommerce_format_decimal( $cart_item['line_subtotal_tax'] ) );

					if ( is_object( $cart_item['data'] ) ) {
						woocommerce_update_order_item_meta( $recurring_item_id, '_tax_class', $cart_item['data']->get_tax_class() );
					}
				}

				$cart_items = $woocommerce->cart->get_cart();
			}

			$item_meta = new WC_Order_Item_Meta( $order_item['item_meta'] );

			// Remove recurring line items and set item totals based on recurring line totals
			foreach ( $item_meta->meta as $meta_key => $meta ) {

				// $meta is an array, so the item needs to be extracted from $meta[0] (just like order meta on a WC Order)
				$meta_value = $meta[0];

				if ( false === $args['checkout_renewal'] ) { // Already set earlier

					// Map line item totals based on recurring line totals
					switch( $meta_key ) {
						case '_recurring_line_total':
							woocommerce_delete_order_item_meta( $recurring_item_id, '_line_total');
							woocommerce_update_order_item_meta( $recurring_item_id, '_line_total', woocommerce_format_decimal( $failed_payment_multiplier * $meta_value ) );
							break;
						case '_recurring_line_tax':
							woocommerce_delete_order_item_meta( $recurring_item_id, '_line_tax');
							woocommerce_update_order_item_meta( $recurring_item_id, '_line_tax', woocommerce_format_decimal( $failed_payment_multiplier * $meta_value ) );
							break;
						case '_recurring_line_subtotal':
							woocommerce_delete_order_item_meta( $recurring_item_id, '_line_subtotal');
							woocommerce_update_order_item_meta( $recurring_item_id, '_line_subtotal', woocommerce_format_decimal( $failed_payment_multiplier * $meta_value ) );
							break;
						case '_recurring_line_subtotal_tax':
							woocommerce_delete_order_item_meta( $recurring_item_id, '_line_subtotal_tax');
							woocommerce_update_order_item_meta( $recurring_item_id, '_line_subtotal_tax', woocommerce_format_decimal( $failed_payment_multiplier * $meta_value ) );
							break;
						default:
							break;
					}
				}

				// Copy over line item meta data, with some parent/child role based exceptions for recurring amounts
				$copy_to_renewal_item = true;
				switch( $meta_key ) {
					case '_recurring_line_total':
					case '_recurring_line_tax':
					case '_recurring_line_subtotal':
					case '_recurring_line_subtotal_tax':
					case '_subscription_recurring_amount':
					//case '_subscription_sign_up_fee':
					case '_subscription_period':
					case '_subscription_interval':
					case '_subscription_length':
					//case '_subscription_trial_period':
					case '_subscription_end_date':
					case '_subscription_expiry_date':
					case '_subscription_start_date':
					case '_subscription_status':
					case '_subscription_completed_payments':
						if ( 'child' == $args['new_order_role'] ) {
							$copy_to_renewal_item = false;
						}
						break;
					//case '_subscription_trial_length': // We never want to duplicate free trials on renewal orders
					//	$copy_to_renewal_item = false;
					//	break;
					case '_subscription_suspension_count': // We want to reset some values for the new order
					//case '_subscription_trial_expiry_date':
					case '_subscription_failed_payments':
						$copy_to_renewal_item = false;
						$meta_value = 0;
						break;
					default:
						break;
				}

				// Copy existing item over to new recurring order item
				if ( $copy_to_renewal_item ) {
					woocommerce_add_order_item_meta( $recurring_item_id, $meta_key, $meta_value );
				}

			}

		}


		if ( false == $args['checkout_renewal'] ) {

			// Add fees
			foreach ( $original_order->get_fees() as $item_id => $order_fee ) {

				if ( ! isset( $order_fee['recurring_line_total'] ) ) {
					continue;
				}

				$item_id = woocommerce_add_order_item( $renewal_order_id, array(
					'order_item_name' => $order_fee['name'],
					'order_item_type' => 'fee'
				) );

				woocommerce_add_order_item_meta( $item_id, '_tax_class', $order_fee['tax_class'] );
				woocommerce_add_order_item_meta( $item_id, '_line_total', WC_Product_Subscription::format_total( $order_fee['recurring_line_total'] ) );
				woocommerce_add_order_item_meta( $item_id, '_line_tax', WC_Product_Subscription::format_total( $order_fee['recurring_line_tax'] ) );
			}

		}

		// Keep a record of the original order's ID on the renewal order
		update_post_meta( $renewal_order_id, '_original_order', $original_order->id, true );

		$renewal_order = new WC_Order( $renewal_order_id );

		if ( 'parent' == $args['new_order_role'] ) {
			WC_Subscriptions_Manager::process_subscriptions_on_checkout( $renewal_order_id );
			$original_order->add_order_note( sprintf( __( 'Order superseded by Renewal Order %s.', 'woocommerce-subscriptions' ), $renewal_order->get_order_number() ) );
		}

		do_action( 'woocommerce_subscriptions_renewal_order_created', $renewal_order, $original_order, $product_id, $args['new_order_role'] );

		return apply_filters( 'woocommerce_subscriptions_renewal_order_id', $renewal_order_id, $original_order, $product_id, $args['new_order_role'] );
	}
}
WC_Subscriptions_Renewal_Order::init();