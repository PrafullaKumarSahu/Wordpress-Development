<?php
/*Customizing checkout fields using actions and filters*/

//Adding custom fields to checkout registration

add_action('woocommerce_before_checkout_billing_form', 'website_information');

 function website_information($checkout){
	
	if( is_subscription_in_cart() ){

		add_filter( 'woocommerce_cart_needs_shipping', '__return_false' ); //disabling shipping for subscription
		
		echo '<div id="website_information"><h2>' . __('Website Information') . '</h2>';
	/* 	
		woocommerce_form_field('email', array(
			'type' => 'text',
			'class' => array('indibits-field-class form-row-wide'),
			'required'  => true,
			'label' => __('Email Address'),
			'placeholder' => __('Email Address'),
		), $checkout->get_value('indibits_filed_name'));
		 */
		woocommerce_form_field('website_address', array(
			'type' => 'text',
			'class' => array('indibits-field-class form-row-wide'),
			'required'  => true,
			'label' => __('Website Address'),
			'placeholder' => __('Website Address'),
		), $checkout->get_value('indibits_filed_name'));
		woocommerce_form_field('wordpress_admin', array(
			'type' => 'text',
			'class' => array('indibits-field-class form-row-wide'),
			'required'  => true,
			'label' => __('Wordpress Admin'),
			'placeholder' => __('Wordpress Admin Username'),
		), $checkout->get_value('indibits_filed_name'));
		woocommerce_form_field('wordpress_password', array(
			'type' => 'password',
			'class' => array('indibits-field-class form-row-wide'),
			'required'  => true,
			'label' => __('Wordpress Password'),
			'placeholder' => __('Wordpress Admin Passsword'),
		), $checkout->get_value('indibits_filed_name'));
		
		echo '</div>';
		
	}
}


//adding validation to fields
//add_action('woocommerce_checkout_process', 'website_information_checkout_field_process');
add_action('woocommerce_checkout_process', 'website_information_checkout_field_process');

 function  website_information_checkout_field_process(){

	if( is_subscription_in_cart() ){
	/* 	if (!$_POST['email']){
			wc_add_notice(__('Email Address Required!'), 'error');
		}
		elseif (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) === false) {
			wc_add_notice(__('Invalid Email Address!'), 'error');
		} */
		if ( !$_POST['website_address'] ){
			wc_add_notice(__('Website Address Required!'), 'error');
			delete_post_meta($post_id, $meta_key );
		}
		elseif (filter_var($_POST['website_address'], FILTER_VALIDATE_URL) === false) {
			wc_add_notice(__('Invalid Website Address!'), 'error');
		}
		if ( !$_POST['wordpress_admin'] )
			wc_add_notice(__('Wordpress Admin Username Required!'), 'error');
		if ( !$_POST['wordpress_password'] )
			wc_add_notice(__('Wordpress Admin Passsword Required!'), 'error');
	}
}


//Update the order meta with fields value
add_action('woocommerce_checkout_update_order_meta', 'website_information_checkout_field_update_order_meta');

 function website_information_checkout_field_update_order_meta($order_id){

	if( is_subscription_in_cart() ){
		/* 	
		if (!empty($_POST['email'])){
			update_post_meta($order_id, 'Email Address', sanitize_text_field($_POST['email']));
		} */
		if (!empty($_POST['website_address'])){
			update_post_meta($order_id, 'website_address', sanitize_text_field($_POST['website_address']));
		}
		if (!empty($_POST['wordpress_admin'])){
			update_post_meta($order_id, 'website_admin', sanitize_text_field($_POST['wordpress_admin']));
		}
		if (!empty($_POST['wordpress_password'])){
			update_post_meta($order_id, 'website_password', sanitize_text_field($_POST['wordpress_password']));
		}
	}
}


//Display field value on the order edit page
add_action('woocommerce_admin_order_data_after_billing_address', 'website_information_checkout_field_display_admin_order_meta', 10, 1);
 function website_information_checkout_field_display_admin_order_meta($order){
	 
		$order_product_id = array_column($order->get_items(), 'product_id' );//get product id from order
		$_pf = new WC_Product_Factory();
		$_product = $_pf->get_product($order_product_id[0]);//get product object from product id
		//var_dump( $_product->product_type );
		if ( $_product->product_type != 'subscription' ){
			delete_post_meta( $order->id, 'website_address' );
			delete_post_meta( $order->id, 'website_admin' );
			delete_post_meta( $order->id, 'website_password' );
		} else {
			echo '<h3><strong>' . __('Website Information') . '</strong></h3>';
			//echo '<p><strong>' . __(' Email Address ') . '</strong>' . get_post_meta($order->id, 'Email Address', true) . '</p>';
			echo '<p><strong>' . __(' Website Address ') . '</strong>' . get_post_meta($order->id, 'website_address', true) . '</p>';
			echo '<p><strong>' . __(' Wordpress Admin ') . '</strong>' . get_post_meta($order->id, 'website_admin', true) . '</p>';
			echo '<p><strong>' . __(' Wordpress Passsword ') . '</strong>' . get_post_meta($order->id, 'website_password', true) . '</p>';
		}
		//var_dump(get_post_meta($order->id));
}