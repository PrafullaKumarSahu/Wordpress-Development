<?php
class WC_Subscriptions_Synchroniser {

	public static $setting_id;

	public static $post_meta_key       = '_subscription_payment_sync_date';
	public static $post_meta_key_day   = '_subscription_payment_sync_date_day';
	public static $post_meta_key_month = '_subscription_payment_sync_date_month';

	public static $sync_field_label;
	public static $sync_description;
	public static $sync_description_year;

	public static $billing_period_ranges;

	/**
	 * Bootstraps the class and hooks required actions & filters.
	 *
	 * @since 1.5
	 */
	public static function init() {

		self::$setting_id = WC_Subscriptions_Admin::$option_prefix . '_sync_payments';

		self::$sync_field_label      = __( 'Synchronise Renewals', 'woocommerce-subscriptions' );
		self::$sync_description      = __( 'Align the payment date for all customers who purchase this subscription to a specific day of the week or month.', 'woocommerce-subscriptions' );
		self::$sync_description_year = sprintf( __( 'Align the payment date for this subscription to a specific day of the year. If the date has already taken place this year, the first payment will be processed in %s. Set the day to 0 to disable payment syncing for this product.', 'woocommerce-subscriptions' ), date( 'Y', strtotime( '+1 year' ) ) );
	}
	public static function is_product_synced( $product ) {

		$payment_date = self::get_products_payment_day( $product );

		return ( ( ! is_array( $payment_date ) && $payment_date > 0 ) || ( isset( $payment_date['day'] ) && $payment_date['day'] > 0 ) ) ? true : false;
	}

	/**
	 * Get the day of the week, month or year on which a subscription's payments should be
	 * synchronised to.
	 *
	 * @return int The day the products payments should be processed, or 0 if the payments should not be sync'd to a specific day.
	 * @since 1.5
	 */
	public static function get_products_payment_day( $product ) {

		if ( ! is_object( $product ) ) {
			$payment_date = get_post_meta( $product, self::$post_meta_key, true );
		} else {
			$payment_date = $product->subscription_payment_sync_date;
		}

		return $payment_date;
	}
	public static function cart_contains_synced_subscription() {
		global $woocommerce;

		$cart_contains_synced_subscription = false;

		if ( isset( $woocommerce->cart ) ) {
			foreach ( $woocommerce->cart->get_cart() as $cart_item_key => $cart_item ) {
				if ( ( ! is_array( $cart_item['data']->subscription_payment_sync_date ) && $cart_item['data']->subscription_payment_sync_date > 0 ) || ( is_array( $cart_item['data']->subscription_payment_sync_date ) && $cart_item['data']->subscription_payment_sync_date['day'] > 0 ) ) {
					$cart_contains_synced_subscription = $cart_item;
					break;
				}
			}
		}

		return $cart_contains_synced_subscription;
	}
}
WC_Subscriptions_Synchroniser::init();