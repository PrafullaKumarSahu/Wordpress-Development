<?php
class WC_Subscriptions_Admin{

	public static $tab_name = 'subscriptions';
	
	public static $option_prefix = 'woocommerce_subscriptions';
	
	public static $admin_screen_id;

	public function __construct(){
		
		// Add subscriptions to the product select box
		add_filter( 'product_type_selector', __CLASS__ . '::add_subscription_products_to_select' );
		
		add_action( 'woocommerce_product_options_general_product_data', array( $this, 'subscription_pricing_fields' ) );
		
		add_action( 'save_post', array( $this, 'save_subscription_meta' ), 11 );
		
		add_action( 'add_meta_boxes', __CLASS__ . '::add_meta_boxes', 35 );
		
		add_action( 'woocommerce_product_options_reviews', array( $this, 'subscription_advanced_fields' ) );
		
		add_action( 'pre_user_query', __CLASS__ . '::add_subscribers_to_customers' );
		
		add_filter( 'woocommerce_settings_tabs_array', __CLASS__ . '::add_subscription_settings_tab', 50 );
		
		add_action( 'woocommerce_settings_tabs_subscriptions', __CLASS__ . '::subscription_settings_page' );

		add_action( 'woocommerce_update_options_' . self::$tab_name, __CLASS__ . '::update_subscription_settings' );

		add_action( 'admin_enqueue_scripts', __CLASS__ . '::enqueue_styles_scripts' );
		
		add_filter( 'woocommerce_payment_gateways_setting_columns', __CLASS__ . '::payment_gateways_rewewal_column' );

		add_action( 'woocommerce_payment_gateways_setting_column_renewals', __CLASS__ . '::payment_gateways_rewewal_support' );
		
	}
	
	//add_filter( 'product_type_selector', 'add_subscription_products_to_select' );
	public static function add_subscription_products_to_select( $types ){
		$types[ 'subscription' ] = __( 'Subscription' );
		return $types;
	}
	
	//add_action( 'woocommerce_product_options_general_product_data', 'subscription_pricing_fields' );

	/**
	 * Output the subscription specific pricing fields on the "Edit Product" Admin page.
	 *
	 * @since 1.0
	 */
	public static function subscription_pricing_fields() {
		global $post;

		// Set month as the default billing period
		if ( ! $subscription_period = get_post_meta( $post->ID, '_subscription_period', true ) ) {
		 	$subscription_period = 'month';
		}

		echo '<div class="options_group subscription_pricing show_if_subscription">';

		// Subscription Price
		woocommerce_wp_text_input( array(
			'id'          => '_subscription_price',
			'class'       => 'wc_input_subscription_price',
			'label'       => sprintf( __( 'Subscription Price (%s)', 'woocommerce-subscriptions' ), get_woocommerce_currency_symbol() ),
			'placeholder' => __( 'e.g. 5.90', 'woocommerce-subscriptions' ),
			'type'        => 'text',
			'custom_attributes' => array(
					'step' => 'any',
					'min'  => '0',
				)
			)
		);

		// Subscription Period Interval
		woocommerce_wp_select( array(
			'id'          => '_subscription_period_interval',
			'class'       => 'wc_input_subscription_period_interval',
			'label'       => __( 'Subscription Periods', 'woocommerce-subscriptions' ),
			'options'     => WC_Subscriptions_Manager::get_subscription_period_interval_strings(),
			)
		);

		// Billing Period
		woocommerce_wp_select( array(
			'id'          => '_subscription_period',
			'class'       => 'wc_input_subscription_period',
			'label'       => __( 'Billing Period', 'woocommerce-subscriptions' ),
			'value'       => $subscription_period,
			'description' => __( 'for', 'woocommerce-subscriptions' ),
			'options'     => WC_Subscriptions_Manager::get_subscription_period_strings(),
			)
		);

		// Subscription Length
		woocommerce_wp_select( array(
			'id'          => '_subscription_length',
			'class'       => 'wc_input_subscription_length',
			'label'       => __( 'Subscription Length', 'woocommerce-subscriptions' ),
			'options'     => WC_Subscriptions_Manager::get_subscription_ranges( $subscription_period ),
			'description' => '',
			)
		);
		do_action( 'woocommerce_subscriptions_product_options_pricing' );

		echo '</div>';
		echo '<div class="show_if_subscription clear"></div>';
	}

	
	/**
	 * Return an i18n'ified associative array of all possible subscription periods.
	 *
	 * @since 1.0
	 */
	function get_subscription_period_interval_strings( $interval = '' ) {

		$intervals = array( 1 => __( 'per', 'wpluv-subscriptions' ) );

		foreach ( range( 2, 6 ) as $i )
			$intervals[ $i ] = sprintf( __( 'every %s', 'wpluv-subscriptions' ), $this->append_numeral_suffix( $i )  );

		$intervals = apply_filters( 'woocommerce_subscription_period_interval_strings', $intervals );

		if ( empty( $interval ) )
			return $intervals;
		else
			return $intervals[ $interval ];
	}
	
	function get_subscription_period_strings( $number = 1, $period = '' ) {

		$translated_periods = apply_filters( 'woocommerce_subscription_periods',
			array(
				'day'   => sprintf( _n( 'day', '%s days', $number, 'wpluv-subscriptions' ), $number ),
				'week'  => sprintf( _n( 'week', '%s weeks', $number, 'wpluv-subscriptions' ), $number ),
				'month' => sprintf( _n( 'month', '%s months', $number, 'wpluv-subscriptions' ), $number ),
				'year'  => sprintf( _n( 'year', '%s years', $number, 'wpluv-subscriptions' ), $number )
			)
		);

		return ( ! empty( $period ) ) ? $translated_periods[ $period ] : $translated_periods;
	}
	
	/**
	 * Returns an array of subscription lengths. 
	 *
	 * PayPal Standard Allowable Ranges
	 * D – for days; allowable range is 1 to 90
	 * W – for weeks; allowable range is 1 to 52
	 * M – for months; allowable range is 1 to 24
	 * Y – for years; allowable range is 1 to 5
	 *
	 * @param subscription_period string (optional) One of day, week, month or year. If empty, all subscription ranges are returned.
	 * @since 1.0
	 */
	function get_subscription_ranges( $subscription_period = '' ) {

		$subscription_periods = $this->get_subscription_period_strings();

		foreach ( array( 'day', 'week', 'month', 'year' ) as $period ) {

			$subscription_lengths = array( 
				__( 'all time', 'wpluv-subscriptions' ),
			);

			switch( $period ) {
				case 'day':
					$subscription_lengths[] = __( '1 day', 'wpluv-subscriptions' );
					break;
				case 'week':
					$subscription_lengths[] = __( '1 week', 'wpluv-subscriptions' );
					break;
				case 'month':
					$subscription_lengths[] = __( '1 month', 'wpluv-subscriptions' );
					break;
				case 'year':
					$subscription_lengths[] = __( '1 year', 'wpluv-subscriptions' );
					break;
			}

			switch( $period ) {
				case 'day':
					$subscription_range = range( 2, 90 );
					break;
				case 'week':
					$subscription_range = range( 2, 52 );
					break;
				case 'month':
					$subscription_range = range( 2, 24 );
					break;
				case 'year':
					$subscription_range = range( 2, 5 );
					break;
			}

			foreach ( $subscription_range as $number )
				$subscription_range[ $number ] = $this->get_subscription_period_strings( $number, $period );

			// Add the possible range to all time range
			$subscription_lengths += $subscription_range;

			$subscription_ranges[ $period ] = $subscription_lengths;
		}

		$subscription_ranges = apply_filters( 'woocommerce_subscription_lengths', $subscription_ranges, $subscription_period );

		if ( ! empty( $subscription_period ) )
			return $subscription_ranges[ $subscription_period ];
		else
			return $subscription_ranges;
	}
	
	function get_available_time_periods( $form = 'singular' ) {

		$number = ( 'singular' == $form ) ? 1 : 2;

		$translated_periods = apply_filters( 'woocommerce_subscription_available_time_periods',
			array(
				'day'   => _n( 'day', 'days', $number, 'wpluv-subscriptions' ),
				'week'  => _n( 'week', 'weeks', $number, 'wpluv-subscriptions' ),
				'month' => _n( 'month', 'months', $number, 'wpluv-subscriptions' ),
				'year'  => _n( 'year', 'years', $number, 'wpluv-subscriptions' )
			)
		);

		return $translated_periods;
	}
	
	//Add users with subscriptions to the "Customers" report in WooCommerce -> Reports.
	public static function add_subscribers_to_customers( $user_query ) {
		//global $plugin_page, $wpdb;
		global $wpdb;

		//if ( ! is_admin() || $plugin_page !== 'woocommerce_reports' || ! isset( $_GET['tab'] ) ) {
		if ( ! is_admin() || ! isset( $_GET['tab'] )) {
			return $user_query;
		}

		if ( 'customers' === $_GET['tab'] && isset( $user_query->query_vars['role'] ) && $user_query->query_vars['role'] === 'customer' ) {
			$users_with_subscriptions = WC_Subscriptions_Manager::get_all_users_subscriptions();
			$include_user_ids = array();
			foreach ( $users_with_subscriptions as $user_id => $subscriptions ) {
				if ( !empty($subscriptions) ) {
					$include_user_ids[] = $user_id;
				}
			}

			if ( !empty($include_user_ids) ) {
				//Turn the original customer query into a sub-query.
				$user_query->query_from = "FROM {$wpdb->users} LEFT JOIN (
						SELECT {$wpdb->users}.ID
						{$user_query->query_from}
						{$user_query->query_where}
					) AS customers ON (customers.ID = {$wpdb->users}.ID)";

				//Select users with subscriptions + customers returned by the original query.
				$user_query->query_where = sprintf(
					"WHERE ({$wpdb->users}.ID IN (%s)) OR (customers.ID IS NOT NULL)",
					implode(', ', $include_user_ids)
				);
			}
		}
	}
	
	/**
	 * Returns either a string or array of strings describing the allowable trial period range
	 * for a subscription.
	 *
	 * @since 1.0
	 */
	function get_trial_period_validation_message( $form = 'combined' ) {

		$subscription_ranges = $this->get_subscription_ranges();

		if ( 'combined' == $form ) {
			$error_message = sprintf( __( 'The trial period can not exceed: %1s, %2s, %3s or %4s.', 'wpluv-subscriptions' ), array_pop( $subscription_ranges['day'] ), array_pop( $subscription_ranges['week'] ), array_pop( $subscription_ranges['month'] ), array_pop( $subscription_ranges['year'] ) );
		} else {
			foreach ( $this->get_available_time_periods() as $period => $string )
				$error_message[ $period ] = sprintf( __( 'The trial period can not exceed %1s.', 'wpluv-subscriptions' ), array_pop( $subscription_ranges[ $period ] ) );
		}

		return apply_filters( 'woocommerce_subscriptions_trial_period_validation_message', $error_message );
	}
	
	//add_action( 'save_post', 'save_subscription_meta', 11 );
		/**
	 * Save meta data for simple subscription product type when the "Edit Product" form is submitted.
	 *
	 * @param array Array of Product types & their labels, excluding the Subscription product type.
	 * @return array Array of Product types & their labels, including the Subscription product type.
	 * @since 1.0
	 */
	function save_subscription_meta( $post_id ) {

		if ( ! isset( $_POST['product-type'] )  ) {
			return;
		}

		$subscription_price = $this->clean_number( stripslashes( $_REQUEST['_subscription_price'] ) );
		$sale_price         = $this->clean_number( stripslashes( $_REQUEST['_sale_price'] ) );
		
		update_post_meta( $post_id, '_subscription_price', $subscription_price );

		// Set sale details - these are ignored by WC core for the subscription product type
		update_post_meta( $post_id, '_regular_price', $subscription_price );
		update_post_meta( $post_id, '_sale_price', $sale_price );

		$date_from = ( isset( $_POST['_sale_price_dates_from'] ) ) ? strtotime( $_POST['_sale_price_dates_from'] ) : '';
		$date_to   = ( isset( $_POST['_sale_price_dates_to'] ) ) ? strtotime( $_POST['_sale_price_dates_to'] ) : '';

		$now = gmdate( 'U' );

		if ( ! empty( $date_to ) && empty( $date_from ) )
			$date_from = $now;

		update_post_meta( $post_id, '_sale_price_dates_from', $date_from );
		update_post_meta( $post_id, '_sale_price_dates_to', $date_to );

		// Update price if on sale
		if ( ! empty( $sale_price ) && ( ( empty( $date_to ) && empty( $date_from ) ) || ( $date_from < $now && ( empty( $date_to ) || $date_to > $now ) ) ) )
			$price = $sale_price;
		else
			$price = $subscription_price;

		update_post_meta( $post_id, '_price', stripslashes( $price ) );

		// Make sure trial period is within allowable range
		$subscription_ranges = $this->get_subscription_ranges();

		if ( ! isset( $_REQUEST['_subscription_limit'] ) )
			$_REQUEST['_subscription_limit'] = 'no';

		$subscription_fields = array(
			'_subscription_period',
			'_subscription_period_interval',
			'_subscription_length',
			'_subscription_limit',
		);

		foreach ( $subscription_fields as $field_name )
			update_post_meta( $post_id, $field_name, stripslashes( $_REQUEST[ $field_name ] ) );

	}

	/**
	 * Callback for the [subscriptions] shortcode that displays subscription names for a particular user.
	 *
	 * @param array $attributes Shortcode attributes.
	 * @return string
	 */
	function clean_number( $number ) {

		$number = preg_replace( "/[^0-9\.]/", '', $number );

		return $number;
	}
	
	// Add advanced subscription options on edit product page
	//add_action( 'woocommerce_product_options_reviews', 'subscription_advanced_fields' );
	/**
	 * Output advanced subscription options on the "Edit Product" admin screen
	 *
	 * @since 1.3.5
	 */
	function subscription_advanced_fields() {
		
		global $post;

		echo '</div>';
		echo '<div class="options_group limit_subscription">';

		// Only one Subscription per customer
		woocommerce_wp_checkbox( array(
			'id'          => '_subscription_limit',
			'label'       => __( 'Limit Subscription', 'wpluv-subscriptions' ),
			'cbvalue'     => 'yes',
			'description' => sprintf( __( 'Only allow a customer to have one subscription to this product. %sLearn more.%s', 'wpluv-subscriptions' ), '<a href="http://docs.woothemes.com/document/subscriptions/store-manager-guide/#limit-subscription">', '</a>' ),
			)
		);

		do_action( 'woocommerce_subscriptions_product_options_advanced' );

	}
	/**
	 * Returns the trial period of a subscription product, if it is a subscription.
	 *
	 * @param mixed $product A WC_Product object or product ID
	 * @return string A string representation of the period, either Day, Week, Month or Year, or an empty string if product is not a subscription or there is no trial
	 * @since 1.2
	 */
	public static function get_trial_period( $product ) {

		if ( ! is_object( $product ) )
			$product = WC_Product_Subscription::get_product( $product );

		if ( ! self::is_subscription( $product ) )
			$subscription_trial_period = '';
		elseif ( ! isset( $product->subscription_trial_period ) && ! isset( $product->product_custom_fields['_subscription_trial_period'][0] ) ) // Backward compatibility
			$subscription_trial_period = self::get_period( $product );
		else
			$subscription_trial_period = isset( $product->subscription_trial_period ) ? $product->subscription_trial_period : $product->product_custom_fields['_subscription_trial_period'][0];

		return apply_filters( 'woocommerce_subscriptions_product_trial_period', $subscription_trial_period, $product );
	}
	
	public static function add_subscription_settings_tab( $settings_tabs ) {

		$settings_tabs[self::$tab_name] = __( 'Subscriptions', 'wpluv-subscriptions' );

		return $settings_tabs;
	}
	public static function subscription_settings_page() {
	
		//var_dump(self::get_settings());
		woocommerce_admin_fields( self::get_settings() );
		
	}
	public static function get_settings() {
	
		global $woocommerce;

		$available_gateways = array();
		
		foreach ( $woocommerce->payment_gateways->payment_gateways() as $gateway ) {
			if ( $gateway->supports( 'subscriptions' ) ) {
				$available_gateways[] = $gateway->title;
			}
		}
		
		if ( count( $available_gateways ) == 0 ) {
			$available_gateways_description = sprintf( __( 'No payment gateways capable of processing automatic subscription payments are enabled. Please enable the %sPayPal Standard%s gateway.', 'wpluv-subscriptions' ), '<strong><a href="' . admin_url( 'admin.php?page=woocommerce&tab=payment_gateways#gateway-paypal' ) . '">', '</a></strong>' );
		} elseif ( count( $available_gateways ) == 1 ) {
			$available_gateways_description = sprintf( __( 'The %s gateway is enabled and can process automatic subscription payments.', 'wpluv-subscriptions' ), '<strong>' . $available_gateways[0] . '</strong>' );
		} elseif ( count( $available_gateways ) > 1 ) {
			$available_gateways_description = sprintf( __( 'The %s & %s gateways can process automatic subscription payments.', 'wpluv-subscriptions' ), '<strong>' . implode( '</strong>, <strong>', array_slice( $available_gateways, 0, count( $available_gateways ) - 1 ) ) . '</strong>', '<strong>' . array_pop( $available_gateways ) . '</strong>' );
		}

		return apply_filters( 'woocommerce_subscription_settings', array(
			
			array(
				'type'     => 'title',
				'id'       => self::$option_prefix . '_renewal_options',
				'name'     => __( 'Renewal', 'wpluv-subscriptions' ),
				'desc'     => '',
			),
			array(
				'type'            => 'checkbox',
				'id'              => self::$option_prefix . '_accept_manual_renewals',
				'name'            => __( 'Manual Renewal Payments', 'wpluv-subscriptions' ),
				'default'         => 'no',
				'desc'            => __( 'Accept Manual Renewals', 'wpluv-subscriptions' ),
				'desc_tip'        => sprintf( __( "With manual renewals, a customer's subscription is put on-hold until they login and pay to renew it. %sLearn more%s.", 'wpluv-subscriptions' ), '<a href="http://docs.woothemes.com/document/subscriptions/store-manager-guide/#accept-manual-renewals">', '</a>' ),
				'checkboxgroup'   => 'start',
				'show_if_checked' => 'option',
			),

			array(
				'type'            => 'checkbox',
				'id'              => self::$option_prefix . '_turn_off_automatic_payments',
				'default'         => 'no',
				'desc'            => __( 'Turn off Automatic Payments', 'wpluv-subscriptions' ),
				'desc_tip'        => sprintf( __( 'If you never want a customer to be automatically charged for a subscription renewal payment, you can turn off automatic payments completely. %sLearn more%s.', 'wpluv-subscriptions' ), '<a href="http://docs.woothemes.com/document/subscriptions/store-manager-guide/#turn-off-automatic-payments">', '</a>' ),
				'checkboxgroup'   => 'end',
				'show_if_checked' => 'yes',
			),

			array( 'type' => 'sectionend', 'id' => self::$option_prefix . '_renewal_options' ),

		));
	}
	public static function update_subscription_settings() {

		// Make sure automatic payments are on when manual renewals are switched off
		if ( ! isset( $_POST[self::$option_prefix . '_accept_manual_renewals'] ) && isset( $_POST[self::$option_prefix . '_turn_off_automatic_payments'] ) ) {
			unset( $_POST[self::$option_prefix . '_turn_off_automatic_payments'] );
		}

		woocommerce_update_options( self::get_settings() );
	}
	//Add a column to the Payment Gateway table to show whether the gateway supports automated renewals.
	public static function payment_gateways_rewewal_column( $header ) {

		$header_new = array_slice($header, 0, count($header) - 1, true) +
			array('renewals' => __('Automatic Recurring Payments', 'wpluv-subscriptions') ) + // Ideally, we could add a link to the docs here, but the title is passed through esc_html()
			array_slice($header, count($header) - 1, count($header)-(count($header) - 1), true);

		return $header_new;
	}
	
	/**
	* Check whether the payment gateway passed in supports automated renewals or not.
	* Automatically flag support for Paypal since it is included with subscriptions.
	* Display in the Payment Gateway column.
	*/
	public static function payment_gateways_rewewal_support( $gateway ) {

		echo '<td class="renewals">';
		if ( ( is_array( $gateway->supports ) && in_array( 'subscriptions', $gateway->supports ) ) || $gateway->id == 'paypal' ) {
			echo '<span class="status-enabled tips" data-tip="' . __( 'Supports automatic renewal payments with the WooCommerce Subscriptions extension.', 'wpluv-subscriptions' ) . '">' . __ ( 'Yes', 'wpluv-subscriptions' ) . '</span>';
		} else {
			echo '-';
		}
		echo '</td>';

	}
	
	public static function enqueue_styles_scripts() {
		global $woocommerce, $pagenow, $post;

		// Get admin screen id
	    $screen = get_current_screen();

		$is_woocommerce_screen = ( in_array( $screen->id, array( 'product', 'edit-shop_order', 'shop_order', self::$admin_screen_id, 'users', 'woocommerce_page_wc-settings' ) ) ) ? true : false;
		$is_activation_screen  = true;

		if ( $is_woocommerce_screen ) {

			$dependencies = array( 'jquery' );

			// Version juggling
			if ( WC_Product_Subscription::is_woocommerce_pre_2_1() ) { // WC 2.0
				$woocommerce_admin_script_handle = 'woocommerce_writepanel';
			} elseif ( WC_Product_Subscription::is_woocommerce_pre_2_2() ) { // WC 2.1
				$woocommerce_admin_script_handle = 'woocommerce_admin_meta_boxes';
			} else {
				$woocommerce_admin_script_handle = 'wc-admin-meta-boxes';
			}

			if( $screen->id == 'product' ) {
				$dependencies[] = $woocommerce_admin_script_handle;

				if ( ! WC_Product_Subscription::is_woocommerce_pre_2_2() ) {
					$dependencies[] = 'wc-admin-product-meta-boxes';
					$dependencies[] = 'wc-admin-variation-meta-boxes';
				}

				$script_params = array(
					'productType'              => WC_Product_Subscription::$name,
					'subscriptionLengths'      => WC_Subscriptions_Manager::get_subscription_ranges(),
					'bulkEditPeriodMessage'    => __( 'Enter the new period, either day, week, month or year:', 'woocommerce-subscriptions' ),
					'bulkEditLengthMessage'    => __( 'Enter a new length (e.g. 5):', 'woocommerce-subscriptions' ),
					'bulkEditIntervalhMessage' => __( 'Enter a new interval as a single number (e.g. to charge every 2nd month, enter 2):', 'woocommerce-subscriptions' ),
				);
			} else if ( 'edit-shop_order' == $screen->id ) {
				$script_params = array(
					'bulkTrashWarning' => __( "You are about to trash one or more orders which contain a subscription.\n\nTrashing the orders will also trash the subscriptions purchased with these orders.", 'woocommerce-subscriptions' )
				);
			} else if ( 'shop_order' == $screen->id ) {
				$dependencies[] = $woocommerce_admin_script_handle;

				if ( ! WC_Product_Subscription::is_woocommerce_pre_2_2() ) {
					$dependencies[] = 'wc-admin-order-meta-boxes';
					$dependencies[] = 'wc-admin-order-meta-boxes-modal';
				}

				$script_params = array(
					'bulkTrashWarning'  => __( 'Trashing this order will also trash the subscription purchased with the order.', 'woocommerce-subscriptions' ),
					'changeMetaWarning' => __( "WARNING: Bad things are about to happen!\n\nThe payment gateway used to purchase this subscription does not support modifying a subscription's details.\n\nChanges to the billing period, recurring discount, recurring tax or recurring total may not be reflected in the amount charged by the payment gateway.", 'woocommerce-subscriptions' ),
					'removeItemWarning' => __( "You are deleting a subscription item. You will also need to manually cancel and trash the subscription on the Manage Subscriptions screen.", 'woocommerce-subscriptions' ),
					'roundAtSubtotal'   => esc_attr( get_option( 'woocommerce_tax_round_at_subtotal' ) ),
					'EditOrderNonce'    => wp_create_nonce( 'woocommerce-subscriptions' ),
					'postId'            => $post->ID,
				);
			} else if ( 'users' == $screen->id ) {
				$dependencies[] = 'ajax-chosen';
				$script_params = array(
					'deleteUserWarning' => __( "WARNING: Deleting a user will also remove them from any subscription.", 'woocommerce-subscriptions' )
				);
			} else if ( self::$admin_screen_id == $screen->id ) {
				$dependencies[] = 'ajax-chosen';
				$script_params = array(
					'ajaxDateChangeNonce'  => wp_create_nonce( 'woocommerce-subscriptions' ),
					'searchCustomersNonce' => wp_create_nonce( 'search-customers' ),
					'searchCustomersLabel' => __( 'Show all customers', 'woocommerce-subscriptions' ),
					'searchProductsNonce'  => wp_create_nonce( 'search-products' ),
				);
			}

			$script_params['ajaxLoaderImage'] = $woocommerce->plugin_url() . '/assets/images/ajax-loader.gif';
			$script_params['ajaxUrl']         = admin_url('admin-ajax.php');
			$script_params['isWCPre21']       = var_export( WC_Product_Subscription::is_woocommerce_pre_2_1(), true );
			$script_params['isWCPre22']       = var_export( WC_Product_Subscription::is_woocommerce_pre_2_2(), true );

			wp_enqueue_script( 'woocommerce_subscriptions_admin', get_stylesheet_directory_uri() . '/js/admin.js', $dependencies, filemtime(  get_stylesheet_directory() . '/js/admin.js' ) );
			wp_localize_script( 'woocommerce_subscriptions_admin', 'WCSubscriptions', apply_filters( 'woocommerce_subscriptions_admin_script_parameters', $script_params ) );

			// Maybe add the pointers for first timers
			if ( isset( $_GET['subscription_pointers'] ) && self::show_user_pointers() ) {

				$dependencies[] = 'wp-pointer';

				$pointer_script_params = array(
					'typePointerContent'  => sprintf( __( '%sChoose Subscription%sThe WooCommerce Subscriptions extension adds two new subscription product types - %sSimple subscription%s and %sVariable subscription%s.%s', 'woocommerce-subscriptions' ), '<h3>', '</h3><p>', '<em>', '</em>', '<em>', '</em>', '</p>' ),
					'pricePointerContent' => sprintf( __( '%sSet a Price%sSubscription prices are a little different to other product prices. For a subscription, you can set a billing period, length, sign-up fee and free trial.%s', 'woocommerce-subscriptions' ), '<h3>', '</h3><p>', '</p>' ),
				);

				wp_enqueue_script( 'woocommerce_subscriptions_admin_pointers', get_stylesheet_directory_uri() . '/js/admin-pointers.js', $dependencies, null, true );

				wp_localize_script( 'woocommerce_subscriptions_admin_pointers', 'WCSPointers', apply_filters( 'woocommerce_subscriptions_admin_pointer_script_parameters', $pointer_script_params ) );

				wp_enqueue_style( 'wp-pointer' );
			}

		}

		// Maybe add the admin notice
		if ( $is_activation_screen ) {

			$woocommerce_plugin_dir_file = self::get_woocommerce_plugin_dir_file();

			if ( ! empty( $woocommerce_plugin_dir_file ) ) {

				wp_enqueue_style( 'woocommerce-activation', plugins_url(  '/assets/css/activation.css', self::get_woocommerce_plugin_dir_file() ), array(), null, true );

			}
	
		}
		
		if ( $is_woocommerce_screen || $is_activation_screen ) {
			wp_enqueue_style( 'admin', get_stylesheet_directory_uri() . '/css/admin.css', null, true );
		}
		
	}
	public static function get_woocommerce_plugin_dir_file() {

		$woocommerce_plugin_file = '';

		foreach ( get_option( 'active_plugins', array() ) as $plugin ) {
			if ( substr( $plugin, strlen( '/woocommerce.php' ) * -1 ) === '/woocommerce.php' ) {
				$woocommerce_plugin_file = $plugin;
				break;
			}
		}

		return $woocommerce_plugin_file;
	}
	public static function show_user_pointers(){
		// Get dismissed pointers
		$dismissed = explode( ',', (string) get_user_meta( get_current_user_id(), 'dismissed_wp_pointers', true ) );

		// Pointer has been dismissed
		if ( in_array( 'wcs_pointer', $dismissed ) ) {
			return false;
		} else {
			return true;
		}
	}
/**
	 * Registers the "Renewal Orders" meta box for the "Edit Order" page.
	 */
	public static function add_meta_boxes() {
		global $current_screen, $post_id;

		// Only display the meta box if an order relates to a subscription
		if ( 'shop_order' == $current_screen->id ) {

			$order_contains_subscription = WC_Subscriptions_Order::order_contains_subscription( $post_id );

			if ( $order_contains_subscription || WC_Subscriptions_Renewal_Order::is_renewal( $post_id, array( 'order_role' => 'child' ) ) ) {
				add_meta_box( 'subscription_renewal_orders', __( 'Related Subscription Orders', 'woocommerce-subscriptions' ), __CLASS__ . '::related_orders_meta_box', 'shop_order', 'normal', 'default' );
			}

			if ( $order_contains_subscription || 'add' == $current_screen->action ) {
				if ( ! WC_Product_Subscription::is_woocommerce_pre_2_2() ) {
					add_meta_box( 'woocommerce-order-totals', __( 'Recurring Totals', 'woocommerce-subscriptions' ), __CLASS__ . '::recurring_totals_meta_box', 'shop_order', 'side', 'high' );
				} else {
					// WC 2.1 compatibility
					add_filter( 'woocommerce_admin_order_totals_after_shipping', 'WC_Subscriptions_Order::recurring_order_totals_meta_box_section', 100, 1 );
				}
			}
		}
	}
	public static function recurring_totals_meta_box( $post ) {
		WC_Subscriptions_Order::recurring_order_totals_meta_box_section( $post->ID );
	}
	public static function related_orders_meta_box( $post ) {

		$order = new WC_Order( absint( $post->ID ) );

		do_action( 'woocommerce_subscriptions_related_orders_meta_box', $order, $post );
	}
	public static function add_related_orders_meta_box() {
		_deprecated_function( __CLASS__ . '::' . __FUNCTION__, '1.5.10', __CLASS__ . '::add_meta_boxes()' );
		self::add_meta_boxes();
	}
}
new WC_Subscriptions_Admin();